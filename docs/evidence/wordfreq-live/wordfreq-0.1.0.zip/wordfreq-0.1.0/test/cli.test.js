import { test } from 'node:test';
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { mkdtempSync, writeFileSync, rmSync, chmodSync, symlinkSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { main } from '../src/cli.js';

const BIN = fileURLToPath(new URL('../bin/wordfreq.js', import.meta.url));
const run = (args, input = '') =>
  spawnSync(process.execPath, [BIN, ...args], { encoding: 'utf8', input });
const dir = mkdtempSync(join(tmpdir(), 'wf-'));
test.after(() => rmSync(dir, { recursive: true, force: true }));
const file = join(dir, 'in.txt');
writeFileSync(file, 'b a b c a b');

test('file input ranks words', () => {
  const r = run([file]);
  assert.equal(r.status, 0);
  assert.equal(r.stdout, 'b\t3\na\t2\nc\t1\n');
  assert.equal(r.stderr, '');
});

test('stdin input works', () => {
  const r = run([], 'a a b');
  assert.equal(r.status, 0);
  assert.equal(r.stdout, 'a\t2\nb\t1\n');
});

test('ties sort alphabetically; --top limits', () => {
  assert.equal(run([], 'b a').stdout, 'a\t1\nb\t1\n');
  assert.equal(run(['--top', '1'], 'b a b').stdout, 'b\t2\n');
});

test('empty input prints nothing, exit 0', () => {
  const r = run([], '');
  assert.equal(r.status, 0);
  assert.equal(r.stdout, '');
});

test('--json prints valid array', () => {
  const r = run(['--json', file]);
  assert.equal(r.status, 0);
  assert.deepEqual(JSON.parse(r.stdout), [
    { word: 'b', count: 3 },
    { word: 'a', count: 2 },
    { word: 'c', count: 1 },
  ]);
});

test('--json empty input prints []', () => {
  const r = run(['--json'], '');
  assert.equal(r.status, 0);
  assert.deepEqual(JSON.parse(r.stdout), []);
});

test('missing file exits 2 with path on stderr, empty stdout', () => {
  const p = join(dir, 'nope.txt');
  const r = run([p]);
  assert.equal(r.status, 2);
  assert.equal(r.stdout, '');
  assert.match(r.stderr, /^wordfreq: /);
  assert.ok(r.stderr.includes(p));
});

test('directory exits 2', () => {
  const r = run([dir]);
  assert.equal(r.status, 2);
  assert.equal(r.stdout, '');
  assert.match(r.stderr, /^wordfreq: .*directory/);
});

test('unknown option, bad value, two paths exit 2', () => {
  for (const args of [['--bogus'], ['--top', '0'], [file, file]]) {
    const r = run(args);
    assert.equal(r.status, 2, args.join(' '));
    assert.equal(r.stdout, '');
    assert.match(r.stderr, /^wordfreq: /);
  }
});

test('--help prints usage and exits 0', () => {
  const r = run(['--help']);
  assert.equal(r.status, 0);
  assert.match(r.stdout, /^Usage: wordfreq/);
  assert.equal(r.stderr, '');
});

test('main uses injected io', () => {
  let out = '';
  assert.equal(main(['--min-length', '2'], { readStdin: () => 'a bb bb', stdout: (s) => (out += s) }), 0);
  assert.equal(out, 'bb\t2\n');
});

// ---- W-006 additions: full option / exit-2 coverage via spawned process ----
const words = Array.from({ length: 12 }, (_, i) => `w${String.fromCharCode(97 + i)}`).join(' ');

test('default shows at most 10 words; --top 3 at most 3', () => {
  const d = run([], words);
  assert.equal(d.status, 0);
  assert.equal(d.stdout.trim().split('\n').length, 10);
  assert.equal(d.stderr, '');
  const t = run(['--top', '3'], words);
  assert.equal(t.status, 0);
  assert.equal(t.stdout.trim().split('\n').length, 3);
  assert.equal(run(['--top=2'], words).stdout.trim().split('\n').length, 2);
});

test('--min-length excludes short words; default keeps one-letter words', () => {
  const r = run(['--min-length', '3'], 'is a cat cat the');
  assert.equal(r.status, 0);
  assert.equal(r.stdout, 'cat\t2\nthe\t1\n');
  assert.equal(r.stderr, '');
  assert.equal(run([], 'a is').stdout, 'a\t1\nis\t1\n');
});

test('--json order matches text order, ints and strings', () => {
  const input = 'x y y z z z q q';
  const text = run([], input).stdout.trim().split('\n').map((l) => l.split('\t'));
  const json = JSON.parse(run(['--json'], input).stdout);
  assert.deepEqual(json.map((o) => o.word), text.map((t) => t[0]));
  for (const o of json) {
    assert.equal(typeof o.word, 'string');
    assert.ok(Number.isInteger(o.count));
  }
  assert.equal(run(['--json'], '').stdout.trim(), '[]');
});

test('--json combined with --top and --min-length', () => {
  const r = run(['--json', '--top', '1', '--min-length', '2'], 'a bb bb cc');
  assert.deepEqual(JSON.parse(r.stdout), [{ word: 'bb', count: 2 }]);
});

test('stdin via "-" and path after options', () => {
  assert.equal(run(['-'], 'a a b').stdout, 'a\t2\nb\t1\n');
  assert.equal(run([file, '--top', '1']).stdout, 'b\t3\n');
});

const exit2 = [
  [['--top', '0'], '--top'],
  [['--top', '-1'], '--top'],
  [['--top', 'abc'], '--top'],
  [['--top', '1.5'], '--top'],
  [['--top'], '--top'],
  [['--top', '--json'], '--top'],
  [['--min-length', '0'], '--min-length'],
  [['--min-length', 'abc'], '--min-length'],
  [['--min-length', '-2'], '--min-length'],
  [['--min-length'], '--min-length'],
  [['--bogus'], '--bogus'],
  [['-x'], '-x'],
  [['--json=1'], '--json'],
  [['a.txt', 'b.txt'], 'b.txt'],
];
for (const [args, mention] of exit2) {
  test(`exit 2: wordfreq ${args.join(' ')}`, () => {
    const r = run(args, 'a b c');
    assert.equal(r.status, 2);
    assert.equal(r.stdout, '');
    assert.match(r.stderr, /^wordfreq: /);
    assert.ok(r.stderr.includes(mention), r.stderr);
  });
}

test('exit 2 for unreadable file (stdout empty, path in stderr)', (t) => {
  const p = join(dir, 'secret.txt');
  writeFileSync(p, 'a b');
  chmodSync(p, 0o000);
  if (process.getuid?.() === 0) {
    // root bypasses permission bits; use a path that is a broken symlink instead
    const link = join(dir, 'broken');
    symlinkSync(join(dir, 'missing-target'), link);
    const r = run([link]);
    assert.equal(r.status, 2);
    assert.equal(r.stdout, '');
    assert.ok(r.stderr.includes(link));
    return;
  }
  const r = run([p]);
  assert.equal(r.status, 2);
  assert.equal(r.stdout, '');
  assert.ok(r.stderr.includes(p));
  assert.match(r.stderr, /permission denied/);
});

test('directory error mentions the path; no stdin read needed', () => {
  const r = run([dir], 'a b');
  assert.equal(r.status, 2);
  assert.equal(r.stdout, '');
  assert.ok(r.stderr.includes(dir));
});

test('stdin via file redirect and empty redirect', () => {
  const r = spawnSync('sh', ['-c', `"${process.execPath}" "${BIN}" < "${file}"`], { encoding: 'utf8' });
  assert.equal(r.status, 0);
  assert.equal(r.stdout, 'b\t3\na\t2\nc\t1\n');
  const e = spawnSync('sh', ['-c', `"${process.execPath}" "${BIN}" < /dev/null`], { encoding: 'utf8' });
  assert.equal(e.status, 0);
  assert.equal(e.stdout, '');
  assert.equal(e.stderr, '');
});

test('stdin via shell pipe', () => {
  const r = spawnSync('sh', ['-c', `printf 'x y x' | "${process.execPath}" "${BIN}"`], { encoding: 'utf8' });
  assert.equal(r.status, 0);
  assert.equal(r.stdout, 'x\t2\ny\t1\n');
});

test('closed stdout (EPIPE) exits quietly without stack trace', () => {
  const big = join(dir, 'big.txt');
  writeFileSync(big, Array.from({ length: 50000 }, (_, i) => `w${i}`).join(' '));
  const r = spawnSync(
    'sh',
    ['-c', `"${process.execPath}" "${BIN}" --top 40000 "${big}" | true; echo "status=$?"; exit 0`],
    { encoding: 'utf8' },
  );
  assert.equal(r.stderr, '');
  assert.match(r.stdout, /status=0/);
  // Direct check: stdout closed entirely.
  const c = spawnSync('sh', ['-c', `"${process.execPath}" "${BIN}" --top 40000 "${big}" >&- 2>err.log; echo $?; cat err.log`], {
    encoding: 'utf8',
    cwd: dir,
  });
  assert.doesNotMatch(c.stdout, /\n\s+at /);
});

test('unexpected errors in bin are reported as wordfreq: <message>, exit 70', () => {
  const pre = join(dir, 'boom.mjs');
  writeFileSync(pre, "process.stdout.write = () => { throw new Error('boom'); };\n");
  const r = spawnSync(process.execPath, ['--import', pre, BIN], { encoding: 'utf8', input: 'a' });
  assert.equal(r.status, 70);
  assert.equal(r.stderr, 'wordfreq: boom\n');
});

test('EPIPE thrown from stdout write exits 0 quietly', () => {
  const pre = join(dir, 'epipe.mjs');
  writeFileSync(pre, "process.stdout.write = () => { throw Object.assign(new Error('x'), { code: 'EPIPE' }); };\n");
  const r = spawnSync(process.execPath, ['--import', pre, BIN], { encoding: 'utf8', input: 'a' });
  assert.equal(r.status, 0);
  assert.equal(r.stderr, '');
});

test('unreadable stdin reports stdin error, exit 2, no stack', () => {
  const r = spawnSync('sh', ['-c', `"${process.execPath}" "${BIN}" < /`], { encoding: 'utf8' });
  assert.equal(r.status, 2);
  assert.match(r.stderr, /^wordfreq: stdin: /);
  assert.doesNotMatch(r.stderr, /\n\s+at /);
});
