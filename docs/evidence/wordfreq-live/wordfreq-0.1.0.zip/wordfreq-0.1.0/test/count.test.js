import { test } from 'node:test';
import assert from 'node:assert/strict';
import { tokenize, countWords, rankWords, topWords } from '../src/count.js';

const pairs = (r) => r.map((x) => [x.word, x.count]);

test('tokenize lowercases and folds apostrophes', () => {
  assert.deepEqual(tokenize("Don't don't"), ["don't", "don't"]);
});
test('tokenize folds typographic apostrophes to ASCII', () => {
  assert.deepEqual(tokenize('Don’t'), ["don't"]);
  assert.deepEqual(tokenize('don’t DON\'T'), ["don't", "don't"]);
  assert.deepEqual(tokenize('’tis'), ['tis']);
  assert.deepEqual(tokenize('dogs’'), ['dogs']);
  assert.equal(countWords('Don’t don\'t').get("don't"), 2);
});
test('tokenize splits on punctuation', () => {
  assert.deepEqual(tokenize('hello,world'), ['hello', 'world']);
});
test('tokenize keeps unicode letters and digits', () => {
  assert.deepEqual(tokenize('Ünï café 42'), ['ünï', 'café', '42']);
});
test('tokenize strips edge apostrophes', () => {
  assert.deepEqual(tokenize("'''quoted'''"), ['quoted']);
  assert.deepEqual(tokenize("' '' a"), ['a']);
});
test('tokenize empty / invalid', () => {
  assert.deepEqual(tokenize(''), []);
  assert.throws(() => tokenize(null), TypeError);
});
test('ranking by count desc', () => {
  assert.deepEqual(pairs(topWords('b a b c a b')), [['b', 3], ['a', 2], ['c', 1]]);
});
test('ties broken alphabetically', () => {
  assert.deepEqual(pairs(topWords('b a')), [['a', 1], ['b', 1]]);
});
test('top limits and fewer distinct words', () => {
  assert.equal(topWords('b a b c a b', { top: 2 }).length, 2);
  assert.equal(topWords('a b', { top: 10 }).length, 2);
});
test('empty input yields nothing', () => {
  assert.deepEqual(topWords(''), []);
});
test('minLength', () => {
  const r = pairs(topWords('is a the cat', { minLength: 3 }));
  assert.deepEqual(r, [['cat', 1], ['the', 1]]);
  assert.equal(topWords('is a').length, 2);
  assert.equal(topWords('is a', { minLength: 0 }).length, 2);
});
test('invalid options throw', () => {
  assert.throws(() => countWords('a', { minLength: -1 }), RangeError);
  assert.throws(() => countWords('a', { minLength: 'x' }), RangeError);
  assert.throws(() => rankWords(new Map(), { top: 0 }), RangeError);
});
test('rankWords accepts Map', () => {
  assert.deepEqual(pairs(rankWords(new Map([['x', 1], ['y', 2]]))), [['y', 2], ['x', 1]]);
});
test('large input performance (~5MB)', () => {
  const words = Array.from({ length: 5000 }, (_, i) => 'w' + i);
  let s = '';
  const parts = [];
  for (let i = 0; i < 800000; i++) parts.push(words[(i * 7919) % 5000]);
  s = parts.join(' ');
  assert.ok(s.length > 4_000_000);
  const t = Date.now();
  const r = topWords(s, { top: 10 });
  assert.ok(Date.now() - t < 5000);
  assert.equal(r.length, 10);
});

test('case folding merges case variants into one word', () => {
  assert.deepEqual(pairs(topWords("Don't don't DON'T Hello hello")), [["don't", 3], ['hello', 2]]);
  assert.deepEqual(pairs(topWords('ÜBER über')), [['über', 2]]);
});
test('digits are word characters and counted', () => {
  assert.deepEqual(pairs(topWords('42 42 a1 a')), [['42', 2], ['a', 1], ['a1', 1]]);
});
test('ties are alphabetical regardless of input order', () => {
  const expected = [['a', 1], ['b', 1], ['c', 1]];
  for (const input of ['c b a', 'a b c', 'b c a', 'b a c']) {
    assert.deepEqual(pairs(topWords(input)), expected, input);
  }
  assert.deepEqual(pairs(rankWords(new Map([['b', 2], ['a', 2], ['c', 3]]))), [['c', 3], ['a', 2], ['b', 2]]);
});
test('top applies after tie ordering', () => {
  assert.deepEqual(pairs(topWords('c b a b', { top: 2 })), [['b', 2], ['a', 1]]);
  assert.deepEqual(pairs(topWords('b a', { top: 1 })), [['a', 1]]);
});
test('minLength 3 excludes is and a; default keeps one-letter words', () => {
  assert.deepEqual(pairs(topWords('is a cat', { minLength: 3 })), [['cat', 1]]);
  assert.deepEqual(pairs(topWords('is a cat')), [['a', 1], ['cat', 1], ['is', 1]]);
});
test('minLength counts code points, not UTF-16 units', () => {
  assert.equal(countWords('𠀀𠀁', { minLength: 2 }).size, 1);
  assert.equal(countWords('é', { minLength: 2 }).size, 0);
});
test('whitespace/punctuation-only input yields nothing', () => {
  assert.deepEqual(tokenize(' \n\t ,.! -- '), []);
  assert.deepEqual(topWords('  ...  '), []);
  assert.equal(countWords('').size, 0);
});
test('importing the module has no side effects', async () => {
  const out = [];
  const orig = process.stdout.write;
  process.stdout.write = (...a) => (out.push(a[0]), true);
  try {
    await import('../src/count.js?fresh=1');
  } finally {
    process.stdout.write = orig;
  }
  assert.deepEqual(out, []);
});
test('NFD and NFC café are the same word', () => {
  assert.deepEqual(tokenize('café café'), ['café', 'café']);
});
test('Devanagari combining marks keep words whole', () => {
  assert.equal(tokenize('नमस्ते दुनिया').length, 2);
});
test('İstanbul is a single token', () => {
  assert.equal(tokenize('İstanbul').length, 1);
});

test('U+2019 is an in-word apostrophe normalized to ASCII', () => {
  assert.deepEqual(tokenize('Don’t'), ["don't"]);
  assert.deepEqual(tokenize("don’t DON'T"), ["don't", "don't"]);
  assert.equal(countWords("Don’t don't").get("don't"), 2);
  assert.deepEqual(tokenize('’tis'), ['tis']);
  assert.deepEqual(tokenize('dogs’'), ['dogs']);
});
test('U+2018 stays a separator', () => {
  assert.deepEqual(tokenize('don‘t'), ['don', 't']);
});
