import { test } from 'node:test';
import assert from 'node:assert/strict';
import { parseArgs, UsageError } from '../src/cli.js';

const bad = (argv, re) => assert.throws(() => parseArgs(argv), (e) => e instanceof UsageError && re.test(e.message));

test('defaults', () => {
  assert.deepEqual(parseArgs([]), { top: 10, minLength: 1, json: false, help: false, path: null });
});
test('all options and path', () => {
  assert.deepEqual(parseArgs(['--top', '3', '--min-length', '2', '--json', 'f.txt']),
    { top: 3, minLength: 2, json: true, help: false, path: 'f.txt' });
});
test('--opt=value forms', () => {
  const r = parseArgs(['--top=5', '--min-length=4', 'a.txt']);
  assert.equal(r.top, 5);
  assert.equal(r.minLength, 4);
});
test('options after path, --help, -- separator', () => {
  assert.equal(parseArgs(['f', '--top', '2']).top, 2);
  assert.equal(parseArgs(['--help']).help, true);
  assert.equal(parseArgs(['--', '--weird']).path, '--weird');
});
for (const v of ['0', '-1', 'abc', '1.5', '', '1e2', ' 3', '99999999999999999999']) {
  test(`invalid --top value ${JSON.stringify(v)}`, () => {
    bad(['--top', v], /--top/);
    bad([`--top=${v}`], /--top/);
  });
}
for (const v of ['0', 'abc', '-2', '2.5']) {
  test(`invalid --min-length value ${JSON.stringify(v)}`, () => bad(['--min-length', v], /--min-length/));
}
test('missing values', () => {
  bad(['--top'], /requires a value/);
  bad(['--min-length'], /requires a value/);
  bad(['--top', '--json'], /requires a value/);
});
test('unknown options', () => {
  bad(['--nope'], /unknown option: --nope/);
  bad(['-x'], /unknown option/);
});
test('multiple paths', () => bad(['a', 'b'], /only one path/));
test('flag with value rejected', () => bad(['--json=1'], /does not take a value/));

test('--top accepts large safe integers, rejects unsafe/whitespace/plus', () => {
  assert.equal(parseArgs(['--top', '1000']).top, 1000);
  for (const v of ['9007199254740993', ' 1', '+1', '1e2', '']) bad(['--top', v], /--top/);
});

test('single dash is a path; --top=value with equals empty is invalid', () => {
  assert.equal(parseArgs(['-']).path, '-');
  bad(['--top='], /--top/);
});
