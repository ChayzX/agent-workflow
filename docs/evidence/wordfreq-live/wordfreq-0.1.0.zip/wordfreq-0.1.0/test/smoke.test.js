import { test } from 'node:test';
import assert from 'node:assert/strict';
import { PLACEHOLDER } from '../src/count.js';

test('count module loads', () => {
  assert.equal(PLACEHOLDER, true);
});
