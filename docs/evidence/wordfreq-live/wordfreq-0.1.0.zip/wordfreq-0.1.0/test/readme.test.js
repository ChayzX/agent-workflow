// R-011: README contains the required sections and its documented examples match real output.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const readme = readFileSync(join(root, 'README.md'), 'utf8');
const bin = join(root, 'bin', 'wordfreq.js');

// Same content as the README "Example input" section (sample.txt).
const SAMPLE = "The cat and the hat. The cat sat on the mat!\nIt's the cat's day; don't 42 42 café CAFÉ.\n";

function run(args, input = SAMPLE) {
  const r = spawnSync(process.execPath, [bin, ...args], { input, encoding: 'utf8' });
  return { stdout: r.stdout, stderr: r.stderr, status: r.status };
}

test('README has the required sections', () => {
  for (const h of ['Installation', 'Usage', 'Options', 'Exit codes', 'Development', 'Tokenization rules']) {
    assert.match(readme, new RegExp(`^## ${h}$`, 'm'), `missing section: ${h}`);
  }
});

test('README documents the install methods', () => {
  for (const cmd of ['npm install -g .', 'npm link', 'npx --no-install wordfreq']) {
    assert.ok(readme.includes(cmd), `missing install command: ${cmd}`);
  }
});

test('README file example output matches a real run', () => {
  const r = run(['--top', '10'], SAMPLE);
  assert.equal(r.status, 0);
  assert.ok(readme.includes(
    '```sh\n$ wordfreq sample.txt\n' + r.stdout.replace(/\n$/, '') + '\n```'
  ));
});

test('README stdin example output matches a real run', () => {
  const r = run(['--top', '3'], 'the quick brown the fox\n');
  assert.equal(r.stdout, 'the\t2\nbrown\t1\nfox\t1\n');
  assert.ok(readme.includes('$ printf \'the quick brown the fox\\n\' | wordfreq --top 3\n' + r.stdout));
});

test('README JSON example output matches a real run', () => {
  const r = run(['--json', '--top', '3']);
  assert.ok(readme.includes('$ wordfreq --json --top 3 sample.txt\n' + r.stdout));
});

test('README min-length example output matches a real run', () => {
  const r = run(['--min-length', '3', '--top', '4']);
  assert.ok(readme.includes('$ wordfreq --min-length 3 --top 4 sample.txt\n' + r.stdout));
});

test('README documented error exit code is 2', () => {
  const r = run(['--top', '0']);
  assert.equal(r.status, 2);
  assert.ok(readme.includes("wordfreq: invalid value for --top: '0' (expected a positive integer)"));
  assert.equal(r.stderr.split('\n')[0], "wordfreq: invalid value for --top: '0' (expected a positive integer)");
});

test('README documents every exported API function and CLI option', () => {
  for (const name of ['tokenize', 'countWords', 'rankWords', 'topWords', '--top', '--min-length', '--json', '--help']) {
    assert.ok(readme.includes('`' + name) || readme.includes(name), `missing: ${name}`);
  }
  assert.match(readme, /rankWords\(counts/);
});

test('README is included in the npm pack tarball', () => {
  const r = spawnSync('npm', ['pack', '--dry-run', '--json', '--ignore-scripts'], { cwd: root, encoding: 'utf8' });
  assert.equal(r.status, 0, r.stderr);
  const files = JSON.parse(r.stdout)[0].files.map((f) => f.path);
  assert.ok(files.includes('README.md'));
});
