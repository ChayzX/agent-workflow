// Packs the package, installs the tarball into a fresh temp project and runs the bin.
import { spawnSync } from 'node:child_process';
import { mkdtempSync, rmSync, readdirSync, existsSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const work = mkdtempSync(join(tmpdir(), 'wordfreq-verify-'));
const packDir = join(work, 'pack');
const appDir = join(work, 'app');

function run(cmd, args, opts = {}) {
  const r = spawnSync(cmd, args, { encoding: 'utf8', shell: process.platform === 'win32', ...opts });
  if (r.status !== 0) {
    process.stderr.write(`command failed: ${cmd} ${args.join(' ')}\n${r.stdout}${r.stderr}`);
    throw new Error(`${cmd} exited with ${r.status}`);
  }
  return r.stdout;
}

try {
  run('node', ['-e', `require('node:fs').mkdirSync(${JSON.stringify(packDir)}, { recursive: true }); require('node:fs').mkdirSync(${JSON.stringify(appDir)}, { recursive: true })`]);
  run('npm', ['pack', '--pack-destination', packDir, '--silent'], { cwd: root });
  const tgz = readdirSync(packDir).filter((f) => f.endsWith('.tgz'));
  if (tgz.length !== 1) throw new Error(`expected one tarball, found ${tgz.length}`);
  run('npm', ['init', '-y'], { cwd: appDir, stdio: 'ignore' });
  run('npm', ['install', '--offline', '--no-audit', '--no-fund', join(packDir, tgz[0])], { cwd: appDir });
  const bin = join(appDir, 'node_modules', '.bin', process.platform === 'win32' ? 'wordfreq.cmd' : 'wordfreq');
  if (!existsSync(bin)) throw new Error(`installed bin not found at ${bin}`);
  // Tarball contents: bin, src, README, LICENSE.
  const listing = run('tar', ['-tzf', join(packDir, tgz[0])]).split('\n').filter(Boolean).map((l) => l.replace(/^package\//, ''));
  for (const want of ['bin/wordfreq.js', 'src/count.js', 'src/cli.js', 'README.md', 'LICENSE', 'package.json']) {
    if (!listing.includes(want)) throw new Error(`tarball is missing ${want}`);
  }
  // Exact allowlist: only bin/, src/, README, package.json (LICENSE is always added by npm).
  for (const f of listing) {
    if (!/^(bin\/|src\/)/.test(f) && !['README.md', 'package.json', 'LICENSE'].includes(f)) {
      throw new Error(`unexpected file in tarball: ${f}`);
    }
  }
  // --help works from the installed bin.
  const h = spawnSync(bin, ['--help'], { encoding: 'utf8', cwd: appDir });
  if (h.status !== 0 || !/Usage: wordfreq/.test(h.stdout)) {
    throw new Error(`installed wordfreq --help failed (status ${h.status}): ${h.stderr}`);
  }
  // Sample run on a file and on stdin.
  const sample = join(appDir, 'sample.txt');
  writeFileSync(sample, 'the cat the dog the end\n');
  const f = spawnSync(bin, ['--top', '1', sample], { encoding: 'utf8', cwd: appDir });
  if (f.status !== 0 || !/the/.test(f.stdout) || !/3/.test(f.stdout)) {
    throw new Error(`installed wordfreq sample run failed (status ${f.status}): ${f.stdout}${f.stderr}`);
  }
  const r = spawnSync(bin, ['--json'], { encoding: 'utf8', cwd: appDir, input: 'a b a\n' });
  if (r.status !== 0) throw new Error(`installed wordfreq exited with ${r.status}: ${r.stderr}`);
  JSON.parse(r.stdout);
  // ~5 MB input through the installed bin must finish in under 5 s.
  const words = Array.from({ length: 5000 }, (_, i) => 'w' + i);
  const parts = [];
  for (let i = 0; i < 800000; i++) parts.push(words[(i * 7919) % 5000]);
  const big = join(appDir, 'big.txt');
  writeFileSync(big, parts.join(' ') + '\n');
  const t0 = Date.now();
  const b = spawnSync(bin, ['--top', '10', big], { encoding: 'utf8', cwd: appDir });
  const ms = Date.now() - t0;
  if (b.status !== 0) throw new Error(`large-input run failed (status ${b.status}): ${b.stderr}`);
  if (ms >= 5000) throw new Error(`large-input run took ${ms} ms (limit 5000)`);
  process.stdout.write(`large input (~5 MB) processed in ${ms} ms\n`);
  process.stdout.write('verify:install ok\n');
} finally {
  rmSync(work, { recursive: true, force: true });
}
