// Runs `node --check` on every .js file in the repo (excluding node_modules/.git).
import { spawnSync } from 'node:child_process';
import { readdirSync } from 'node:fs';
import { join, dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const skip = new Set(['node_modules', '.git', 'coverage']);

function* walk(dir) {
  for (const e of readdirSync(dir, { withFileTypes: true })) {
    if (e.isDirectory()) {
      if (!skip.has(e.name)) yield* walk(join(dir, e.name));
    } else if (e.name.endsWith('.js')) {
      yield join(dir, e.name);
    }
  }
}

let failed = 0;
let count = 0;
for (const file of walk(root)) {
  count++;
  const r = spawnSync(process.execPath, ['--check', file], { encoding: 'utf8' });
  if (r.status !== 0) {
    failed++;
    process.stderr.write(`syntax check failed: ${file}\n${r.stderr}`);
  }
}
if (count === 0) {
  process.stderr.write('check: no .js files found\n');
  process.exit(1);
}
if (failed) process.exit(1);
process.stdout.write(`check ok (${count} files)\n`);
