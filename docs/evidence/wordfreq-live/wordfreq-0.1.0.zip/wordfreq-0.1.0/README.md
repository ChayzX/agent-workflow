# wordfreq

A dependency-free Node.js command-line tool that reports the top-N most frequent
words in a text file or on standard input. It also exposes the counting logic as
an importable ES module.

## Requirements

- Node.js **22 or later** (`"engines": { "node": ">=22" }`).
- No runtime dependencies.

## Installation

Clone the repository and install into the local project, or use one of the
options below.

```sh
# From a checkout of this repository
npm ci
```

Install the command globally from a checkout:

```sh
npm install -g .
wordfreq --help
```

Link the command for development (changes to the checkout take effect immediately):

```sh
npm link
wordfreq --help
```

Run without installing, from a checkout that contains the package:

```sh
npx --no-install wordfreq --help
```

> Verification status: `npx --no-install wordfreq` was run from the checkout and
> works. `npm install -g .` and `npm link` were **not** run (they write to the
> global npm prefix); the packed-tarball install path is verified by
> `npm run verify:install` (see [Development](#development)).

## Usage

```sh
wordfreq [options] [file]
```

- With a `file` argument, words are read from that file (UTF-8).
- With no file argument, or with `-` as the file, words are read from standard input.
- Output is one line per word: the word, a tab character, and its count, in
  descending count order.

### Example input

The examples below use a file named `sample.txt`. Create it with:

```sh
printf 'The cat and the hat. The cat sat on the mat!\nIt'"'"'s the cat'"'"'s day; don'"'"'t 42 42 café CAFÉ.\n' > sample.txt
```

### Reading a file

```sh
$ wordfreq sample.txt
the	5
42	2
café	2
cat	2
and	1
cat's	1
day	1
don't	1
hat	1
it's	1
```

### Reading from stdin

```sh
$ printf 'the quick brown the fox\n' | wordfreq --top 3
the	2
brown	1
fox	1
```

### JSON output

```sh
$ wordfreq --json --top 3 sample.txt
[{"word":"the","count":5},{"word":"42","count":2},{"word":"café","count":2}]
```

With `--json`, the output is a single JSON array of `{"word", "count"}` objects.
An input with no words produces `[]`.

### Minimum word length

```sh
$ wordfreq --min-length 3 --top 4 sample.txt
the	5
café	2
cat	2
and	1
```

### Errors

Usage errors print a message and the usage text to standard error and exit with
code 2:

```sh
$ wordfreq --top 0 sample.txt
wordfreq: invalid value for --top: '0' (expected a positive integer)
Usage: wordfreq [options] [file]

Options:
  --top <n>          number of words to show (positive integer, default 10)
  --min-length <n>   minimum word length (positive integer, default 1)
  --json             output JSON
  --help             show this help

Reads from stdin when no file is given.
```

```sh
$ wordfreq nope.txt
wordfreq: nope.txt: no such file or directory
```

## Options

| Option | Argument | Default | Description |
| --- | --- | --- | --- |
| `--top <n>` | positive integer | `10` | Number of words to show. Also accepts `--top=<n>`. |
| `--min-length <n>` | positive integer | `1` | Exclude words shorter than `n` characters (code points). Also accepts `--min-length=<n>`. |
| `--json` | none | off | Print a JSON array of `{"word", "count"}` objects instead of tab-separated lines. |
| `--help` | none | — | Print usage and exit 0. |
| `--` | none | — | Treat every following argument as a file name, even if it starts with `-`. |

Only one file argument is accepted. Options that take a value and do not
include `=` read the next argument as their value; a following argument that
starts with `--` is treated as a missing value.

## Tokenization rules

Input text is processed as follows:

1. The text is lowercased using Unicode case mapping, so `CAFÉ` and `café` count as the same word.
2. Text is NFC-normalized first. A **word** is a maximal run of Unicode letters (`\p{L}`), combining marks (`\p{M}`), Unicode digits
   (`\p{N}`) and the apostrophe (`'`).
   Typographic apostrophes (`’` U+2019, `ʼ` U+02BC, `＇` U+FF07) are first
   folded to the ASCII apostrophe, so `Don’t` and `don't` are the same word `don't`. The opening quote `‘` (U+2018)
   is not an apostrophe and stays a separator.
3. Leading and trailing apostrophes are removed from each run (so `’tis` becomes `tis`
   and `dogs’` becomes `dogs`). Apostrophes inside
   a word are kept, so `don't` and `cat's` are single words, and `'quoted'`
   becomes `quoted`.
4. Runs that are empty after apostrophe stripping are dropped.
5. Digits count as word characters, so `42` is a word.
6. Every other character (spaces, punctuation, hyphens, symbols) separates words.
   For example, `rock-and-roll` is three words.
7. Words are ranked by count, highest first. Ties are ordered by the word in
   ascending code-unit order, so `42` appears before `cat`.
8. `--min-length` is applied after tokenization and compares the length in code
   points, so accented letters and CJK characters count as one each.

Input is decoded as UTF-8 when read from a file.

## Exit codes

| Code | Meaning |
| --- | --- |
| `0` | Success, including `--help` and input with no words. |
| `2` | Usage error (unknown option, invalid or missing option value, extra file argument, option given a value it does not take), or an input error (file not found, path is a directory, permission denied, other read failure). |

Error messages are written to standard error prefixed with `wordfreq:`.

## Using the library

The counting logic is exported from `src/count.js` and has no I/O:

```js
import { topWords, countWords, tokenize } from 'wordfreq';

topWords('the cat and the hat', { top: 2 });
// [ { word: 'the', count: 2 }, { word: 'and', count: 1 } ]
```

API summary:

- `tokenize(text)` returns an array of lowercase words.
- `countWords(text, { minLength = 1 })` returns a `Map` of word to count.
- `rankWords(counts, { top })` returns `{ word, count }[]` sorted by count
  descending, then word ascending; `top` (integer >= 1) is optional.
- `topWords(text, { top, minLength })` is `tokenize` + `countWords` + `rankWords` in one call.

Importing the module has no side effects.

The package `exports` map exposes only the `.` entry, which points to
`src/count.js`; deep imports such as `wordfreq/src/count.js` are not allowed.
Verified output: `[ { word: 'the', count: 2 }, { word: 'and', count: 1 } ]`.

## Development

Requirements: Node.js 22 or later and npm.

```sh
npm ci                  # install (no dependencies to fetch)
npm test                # run the node:test suite
npm run check           # syntax-check the entry points and scripts
npm run verify:install  # pack the package, install the tarball into a temp project, run the bin
npm run ci              # all of the above: check, test, verify:install
```

Project layout:

- `bin/wordfreq.js` — executable entry point; calls `main()` from `src/cli.js`.
- `src/cli.js` — argument parsing, input/output and exit codes.
- `src/count.js` — pure tokenization, counting and ranking.
- `test/` — `node:test` suites.
- `scripts/verify-install.js` — install verification.

## License

MIT. See [LICENSE](LICENSE).
