# Known limitations

## Open non-blocking findings
- [low] package.json 'files' lists LICENSE and README.md that are not in this diff
- [info] Acceptance commands not executed in this review
- [low] Test name misleading and no coverage for curly apostrophes or combining marks
- [low] Combining marks and curly apostrophes split words
- [low] Code-point minLength test does not distinguish code points from UTF-16 units
- [low] README file example is tested via stdin, not via the file path
- [info] Verification-status note cannot be checked from this review
- [low] Unreadable-file (EACCES) path is not exercised when tests run as root
- [low] Unreadable-file test falls back to a missing-file case when run as root
- [low] Closed-stdout test assertions are weak
- [low] npx --no-install claim is asserted as verified but not covered by any test
- [info] npm run check description understates its scope
- [low] Documented error and empty-input examples lack test coverage
- [info] README API/option test assertion is weak
- [low] İstanbul test asserts only token count, not the token value
- [low] No test for --min-length counting with combining marks

## Not implemented / cancelled
- D-006 Documentation does not match implementation: No external blocker. The audit environment denied Bash, so verification could not run. The finding is stale relative to the current head.
