# Security assessment

Commit: `5927b11bb1a71c81107e32450b74dfb34b92efe7`

- Secret scan of release tree: clean
- Credential-bearing files: none

## Review findings

| Severity | Status | Title |
|---|---|---|
| low | open | package.json 'files' lists LICENSE and README.md that are not in this diff |
| info | open | Acceptance commands not executed in this review |
| low | open | Test name misleading and no coverage for curly apostrophes or combining marks |
| low | open | Combining marks and curly apostrophes split words |
| low | open | Code-point minLength test does not distinguish code points from UTF-16 units |
| low | open | README file example is tested via stdin, not via the file path |
| info | open | Verification-status note cannot be checked from this review |
| low | open | Unreadable-file (EACCES) path is not exercised when tests run as root |
| low | open | Unreadable-file test falls back to a missing-file case when run as root |
| low | open | Closed-stdout test assertions are weak |
| low | open | npx --no-install claim is asserted as verified but not covered by any test |
| info | open | npm run check description understates its scope |
| low | open | Documented error and empty-input examples lack test coverage |
| info | open | README API/option test assertion is weak |
| low | open | İstanbul test asserts only token count, not the token value |
| low | open | No test for --min-length counting with combining marks |
