# Rollback

1. Keep the previous release ZIP and its `.sha256` file.
2. Stop the running service, restore the previous release directory (or check out the previous release commit), and re-run its documented install steps.
3. If database migrations were applied, run the down-migrations documented by the project before restoring, or restore the pre-upgrade backup.
4. Verify with the project's health check / test commands: `npm ci`, `npm test`, `npm run check`.
