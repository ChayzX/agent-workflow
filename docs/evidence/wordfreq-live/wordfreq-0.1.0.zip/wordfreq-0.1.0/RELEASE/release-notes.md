# wordfreq 0.1.0

Built from `5927b11bb1a71c81107e32450b74dfb34b92efe7`.

## Changes
- D-001 README.md is missing (R-011)
- D-004 Requirement R-006 not satisfied: Tokenization and case folding
- D-005 U+2019 curly apostrophe not treated as in-word apostrophe (R-006 clarification unimplemented)
- D-002 Quality gates incomplete: `check` omits tests and there is no single gate script, LICENSE file missing (R-012)
- D-003 stdin read and output robustness in CLI main (R-001, R-007)
- W-001 Scaffold project, test runner and quality gates
- W-002 Core counting module
- W-004 CLI argument parsing and validation
- W-005 CLI main: I/O, output formatting, exit codes
- W-003 Unit tests for counting module
- W-006 End-to-end CLI tests and arg-parser unit tests
- W-007 Write README
- W-008 Installation verification and performance check
- W-009 Final code review against requirements
