// Pure word-counting logic. No I/O, no side effects on import.

// Kept for backward compatibility with the W-001 smoke test.
export const PLACEHOLDER = true;

const TOKEN_RE = /[\p{L}\p{N}\p{M}']+/gu;

/**
 * Split text into lowercase words. Words are runs of letters, combining marks, digits and
 * apostrophes (typographic apostrophes U+2019, U+02BC, U+FF07 are folded to ASCII); leading/trailing apostrophes are stripped.
 * @param {string} text
 * @returns {string[]}
 */
export function tokenize(text) {
  if (typeof text !== 'string') throw new TypeError('text must be a string');
  const out = [];
  const folded = text
    .normalize('NFC')
    .toLowerCase()
    .normalize('NFC')
    .replace(/[’ʼ＇]/g, "'");
  for (const m of folded.matchAll(TOKEN_RE)) {
    let w = m[0];
    let s = 0;
    let e = w.length;
    while (s < e && w.charCodeAt(s) === 39) s++;
    while (e > s && w.charCodeAt(e - 1) === 39) e--;
    if (e > s) out.push(s === 0 && e === w.length ? w : w.slice(s, e));
  }
  return out;
}

function checkInt(value, name, min) {
  if (!Number.isInteger(value) || value < min) {
    throw new RangeError(`${name} must be an integer >= ${min}`);
  }
}

/**
 * Count words. Words shorter than minLength (in code points) are excluded.
 * @param {string} text
 * @param {{minLength?: number}} [options]
 * @returns {Map<string, number>}
 */
export function countWords(text, { minLength = 1 } = {}) {
  checkInt(minLength, 'minLength', 0);
  const counts = new Map();
  for (const w of tokenize(text)) {
    if (minLength > 1 && [...w].length < minLength) continue;
    counts.set(w, (counts.get(w) || 0) + 1);
  }
  return counts;
}

/**
 * Rank counts: count descending, then word ascending (code-unit order).
 * @param {Map<string, number>|Iterable<[string, number]>} counts
 * @param {{top?: number}} [options] top must be an integer >= 1 if given
 * @returns {{word: string, count: number}[]}
 */
export function rankWords(counts, { top } = {}) {
  if (top !== undefined && top !== Infinity) checkInt(top, 'top', 1);
  const arr = Array.from(counts, ([word, count]) => ({ word, count }));
  arr.sort((a, b) => b.count - a.count || (a.word < b.word ? -1 : a.word > b.word ? 1 : 0));
  return top === undefined ? arr : arr.slice(0, top);
}

/**
 * Convenience: tokenize, count and rank.
 * @param {string} text
 * @param {{top?: number, minLength?: number}} [options]
 */
export function topWords(text, { top, minLength } = {}) {
  return rankWords(countWords(text, { minLength }), { top });
}
