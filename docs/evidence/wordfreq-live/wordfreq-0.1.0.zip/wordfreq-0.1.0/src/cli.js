// Command-line interface: argument parsing, I/O and exit codes.
import { readFileSync, readSync, statSync } from 'node:fs';
import { topWords } from './count.js';

export const USAGE = `Usage: wordfreq [options] [file]

Options:
  --top <n>          number of words to show (positive integer, default 10)
  --min-length <n>   minimum word length (positive integer, default 1)
  --json             output JSON
  --help             show this help

Reads from stdin when no file is given.`;

export class UsageError extends Error {
  constructor(message) {
    super(message);
    this.name = 'UsageError';
  }
}

function positiveInt(name, raw) {
  if (raw === undefined) throw new UsageError(`option ${name} requires a value`);
  if (!/^[0-9]+$/.test(raw) || !Number.isSafeInteger(Number(raw)) || Number(raw) < 1) {
    throw new UsageError(`invalid value for ${name}: '${raw}' (expected a positive integer)`);
  }
  return Number(raw);
}

/**
 * Pure argument parser. Throws UsageError on invalid input.
 * @param {string[]} argv
 * @returns {{top:number,minLength:number,json:boolean,help:boolean,path:string|null}}
 */
export function parseArgs(argv = []) {
  const out = { top: 10, minLength: 1, json: false, help: false, path: null };
  let onlyPositionals = false;
  const addPath = (p) => {
    if (out.path !== null) throw new UsageError(`unexpected extra argument: '${p}' (only one path allowed)`);
    out.path = p;
  };
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    if (onlyPositionals || arg === '-' || !arg.startsWith('-')) {
      addPath(arg);
      continue;
    }
    if (arg === '--') {
      onlyPositionals = true;
      continue;
    }
    let name = arg;
    let value;
    const eq = arg.indexOf('=');
    if (arg.startsWith('--') && eq !== -1) {
      name = arg.slice(0, eq);
      value = arg.slice(eq + 1);
    }
    switch (name) {
      case '--top':
      case '--min-length': {
        if (value === undefined && i + 1 < argv.length) {
          const next = argv[i + 1];
          // A following long option means the value is missing; anything else
          // (including '-1') is taken as the value and validated.
          if (!next.startsWith('--')) value = argv[++i];
        }
        const n = positiveInt(name, value);
        if (name === '--top') out.top = n;
        else out.minLength = n;
        break;
      }
      case '--json':
      case '--help':
        if (value !== undefined) throw new UsageError(`option ${name} does not take a value`);
        if (name === '--json') out.json = true;
        else out.help = true;
        break;
      default:
        throw new UsageError(`unknown option: ${name}`);
    }
  }
  return out;
}

function errorMessage(err, path) {
  switch (err && err.code) {
    case 'ENOENT': return `${path}: no such file or directory`;
    case 'EISDIR': return `${path}: is a directory`;
    case 'EACCES': return `${path}: permission denied`;
    default: return `${path}: ${err && err.message ? err.message : String(err)}`;
  }
}

/**
 * Read all of stdin synchronously. Tolerates EAGAIN (non-blocking pipes/TTYs)
 * by waiting briefly and retrying, and treats EOF errors as end of input.
 * @returns {string}
 */
export function readStdinSync(fd = 0, isTTY = process.stdin.isTTY) {
  if (isTTY) process.stderr.write('wordfreq: reading from stdin; press Ctrl-D to finish\n');
  const chunks = [];
  const buf = Buffer.allocUnsafe(65536);
  const sleeper = new Int32Array(new SharedArrayBuffer(4));
  for (;;) {
    let n;
    try {
      n = readSync(fd, buf, 0, buf.length, null);
    } catch (err) {
      if (err && err.code === 'EAGAIN') {
        Atomics.wait(sleeper, 0, 0, 10);
        continue;
      }
      if (err && err.code === 'EOF') break;
      throw err;
    }
    if (n === 0) break;
    chunks.push(Buffer.from(buf.subarray(0, n)));
  }
  return Buffer.concat(chunks).toString('utf8');
}

/**
 * Run the CLI with the given argv (excluding node and script path).
 * @param {string[]} argv
 * @param {{readStdin?: () => string, stdout?: (s: string) => void, stderr?: (s: string) => void}} [io]
 * @returns {number} exit code
 */
export function main(argv = [], io = {}) {
  const readStdin = io.readStdin ?? readStdinSync;
  const stdout = io.stdout ?? ((s) => process.stdout.write(s));
  const stderr = io.stderr ?? ((s) => process.stderr.write(s));
  const fail = (msg) => {
    stderr(`wordfreq: ${msg}\n`);
    return 2;
  };
  let opts;
  try {
    opts = parseArgs(argv);
  } catch (err) {
    if (err instanceof UsageError) return fail(`${err.message}\n${USAGE}`);
    throw err;
  }
  if (opts.help) {
    stdout(`${USAGE}\n`);
    return 0;
  }
  let text;
  try {
    if (opts.path === null || opts.path === '-') {
      text = readStdin();
    } else {
      if (statSync(opts.path).isDirectory()) return fail(`${opts.path}: is a directory`);
      text = readFileSync(opts.path, 'utf8');
    }
  } catch (err) {
    return fail(errorMessage(err, opts.path ?? 'stdin'));
  }
  const ranked = topWords(text, { top: opts.top, minLength: opts.minLength });
  if (opts.json) stdout(`${JSON.stringify(ranked)}\n`);
  else if (ranked.length) stdout(ranked.map((r) => `${r.word}\t${r.count}\n`).join(''));
  return 0;
}
