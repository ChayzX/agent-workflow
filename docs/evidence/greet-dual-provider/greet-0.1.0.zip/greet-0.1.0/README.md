# greet

## Installation

You need Git, Node.js 18 or later, and npm. The package has no dependencies, so
it is ready to use after cloning.

Set `GREET_REPO_URL` to this repository's URL or local path. Run the following
commands from the directory where you want to create the `greet` checkout.

The repository's `.gitattributes` sets `* text=auto eol=lf`, so text files stay
LF in the working tree even when Git is configured with `core.autocrlf=true`
(for example on Windows). The commands below are covered by a test that clones
with `core.autocrlf=true`, which produces LF files under this rule. Checkouts
made before this rule existed may still have CRLF files; re-clone them to get
LF files. Raw CRLF text is not supported as the input to the commands below.

```sh
git clone "$GREET_REPO_URL" greet &&
cd greet &&
npm test
```

## Usage

Save either example as `example.mjs` in the repository root and run
`node example.mjs`. Each example exits silently when the assertion passes.

**`hello(name)`**

Returns a greeting after trimming whitespace from both ends of the name.
Passing a non-string throws a `TypeError`. Passing an empty or whitespace-only
string throws a `RangeError`.

```js
import assert from "node:assert/strict";
import { hello } from "./src/hello.js";

assert.equal(hello("  Ada  "), "Hello, Ada!");
```

**`shout(text)`**

Returns the text in uppercase, preserving punctuation. Passing a non-string
throws a `TypeError`.

```js
import assert from "node:assert/strict";
import { shout } from "./src/shout.js";

assert.equal(shout("hi!"), "HI!");
```

Run `node --test` from the repository root to check both functions and the README
examples.
