/**
 * Returns the greeting for the given name.
 * @param {string} name - non-empty name to greet
 * @returns {string} e.g. hello("Ada") === "Hello, Ada!"
 * @throws {TypeError} if name is not a string
 * @throws {RangeError} if name is empty or whitespace-only
 */
export function hello(name) {
  if (typeof name !== "string") {
    throw new TypeError("name must be a string");
  }
  const trimmed = name.trim();
  if (trimmed.length === 0) {
    throw new RangeError("name must not be empty");
  }
  return `Hello, ${trimmed}!`;
}
