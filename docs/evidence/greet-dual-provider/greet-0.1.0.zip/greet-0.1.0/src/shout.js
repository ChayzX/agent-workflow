/**
 * Returns the input text converted to uppercase.
 * Punctuation is preserved: shout("hi!") === "HI!".
 * @param {string} text
 * @returns {string}
 */
export function shout(text) {
  if (typeof text !== 'string') {
    throw new TypeError('shout(text): text must be a string');
  }
  return text.toUpperCase();
}
