# greet product brief

The requirements below come from the D-006 integration audit. The README format follows [ADR-001](adr/ADR-001.md).

| Requirement | Acceptance criterion | Status | Passing acceptance test |
|---|---|---|---|
| R-001 | `hello("Ada")` returns `"Hello, Ada!"`. | Satisfied | [hello('Ada') returns exactly 'Hello, Ada!'](../test/hello.test.js#L5) |
| R-002 | `shout("hi")` returns `"HI"`. | Satisfied | [shout("hi") returns "HI"](../test/shout.test.js#L5) |
| R-003 | The README has a single Usage section with one labeled, runnable example each for `hello` and `shout`. | Satisfied | [README Usage examples for hello and shout produce the documented output](../test/readme.test.js#L12) |
