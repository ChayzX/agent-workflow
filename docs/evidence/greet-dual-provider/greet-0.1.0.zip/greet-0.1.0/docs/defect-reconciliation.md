# Defect reconciliation

## D-007 (CRLF installation)

Checkout policy: `.gitattributes` sets `* text=auto eol=lf`, so working-tree text files are LF, including in a clone made with `core.autocrlf=true`. The documented installation is supported from an LF checkout, and both README examples run from LF checkouts. The README example extractor also runs both examples from README text with CRLF terminators preserved. Raw CRLF input to the documented `sh` commands is out of scope.

Checkouts made before `.gitattributes` existed may still contain CRLF files; re-clone them to get LF files.

Historical counts, as observed at the D-006 reconciliation (commit `69f027c` and earlier, before the D-005 and D-009 installation tests were added): the required `node --test` gate passed all three test files, and `node --test --experimental-test-isolation=none` reported nine passing cases and zero failures. These counts are not current; later revisions add `test/install.test.js`.

Tests that exercise this policy:

- `test/readme.test.js`: "D-007: README Usage examples ... with CRLF" runs both examples from CRLF text.
- `test/install.test.js`: "D-007: .gitattributes keeps the working tree LF under core.autocrlf=true ..." runs the documented installation from such a clone.
- `test/install.test.js`: "D-007: the sh block with raw CRLF bytes fails in sh ..." documents why LF is enforced; it does not show that the fix works.

## D-001 through D-003

The original defect records and the requirement brief are not available in this repository, so no disposition is recorded here.
