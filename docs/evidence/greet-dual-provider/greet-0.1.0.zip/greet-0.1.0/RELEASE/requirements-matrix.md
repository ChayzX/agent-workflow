# Requirements to evidence

| Req | Title | Status | Evidence |
|---|---|---|---|
| R-001 | hello(name) greeting | verified | W-001 dfebb48aeebb secret-scan=pass,test=pass<br>D-001 042e6b7bb825 secret-scan=pass,test=pass<br>D-006 69f027ca3e34 secret-scan=pass,test=pass<br>aud_ca1d3702ee744aafb1b3 723584c6f64a |
| R-002 | shout(text) uppercase | verified | W-002 a4e1b7bd1d0f secret-scan=pass,test=pass<br>D-002 042e6b7bb825 secret-scan=pass,test=pass<br>D-006 69f027ca3e34 secret-scan=pass,test=pass<br>aud_ca1d3702ee744aafb1b3 723584c6f64a |
| R-003 | README | verified | W-003 042e6b7bb825 secret-scan=pass,test=pass<br>D-003 042e6b7bb825 secret-scan=pass,test=pass<br>D-006 69f027ca3e34 secret-scan=pass,test=pass<br>aud_ca1d3702ee744aafb1b3 723584c6f64a |
