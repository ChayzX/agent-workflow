# Security assessment

Commit: `723584c6f64af04e4e37608fd2df6752901b5674`

- Secret scan of release tree: clean
- Credential-bearing files: none

## Review findings

| Severity | Status | Title |
|---|---|---|
| medium | verified | The installation test bypasses the documented setup commands |
| medium | verified | Installation tests fail from checkout paths containing spaces |
| medium | verified | The documented clone command is invalid shell syntax |
| medium | verified | The documented clone command contains shell redirections |
| medium | verified | The installation test fails when the checkout path contains spaces |
| medium | verified | The installation test passes if the README omits `npm test` |
| medium | verified | D-006 lacks verifiable defect dispositions and brief status |
| medium | verified | Installation test clones a synthetic commit built from working-tree files |
| medium | verified | A failed clone can run tests from an existing checkout |
| medium | verified | Installation fixture produces an incomplete bundle from a shallow checkout |
| high | verified | No product or configuration change addresses CRLF; the defect remains |
| high | verified | Installation test normalizes CRLF away, so it cannot detect the CRLF failure |
| medium | verified | The new D-007 CRLF README test does not test CRLF |
| low | open | Installation test has no explicit CRLF case |
| medium | verified | The attribute test fails when Git or usable repository metadata is unavailable |
| low | open | The reconciliation note cites a commit that already contains the installation tests |
| low | open | The reconciliation misdates the addition of the installation tests |
| medium | verified | Reconciliation doc reports a test result from an uncommitted worktree, not the reviewed commit |
| low | open | CRLF section gives a workaround that does not match the README's own install block |
| low | open | README installation test only checks keywords, not documented behaviour |
| medium | verified | CRLF fix depends on .gitattributes being committed, and the README claims it works in either checkout |
| medium | open | Recorded clean-commit test result has no environment caveat and is unverified |
| medium | verified | .gitattributes fix is not committed in the reviewed state |
| high | verified | CRLF install test never executes the CRLF documented commands |
| medium | verified | Doc claims about the 5561a7a commit history are unverified |
| medium | verified | Reconciliation doc closes D-001..D-003 without supporting records |
| high | verified | Raw CRLF install test never executes CRLF bytes |
| medium | verified | 'CRLF checkout' test cannot produce a CRLF checkout under eol=lf |
| medium | verified | Reconciliation doc cites a different commit than the one under review |
| low | open | Exact test counts documented without git-on-PATH caveat |
| medium | verified | Dispositions still mark D-001..D-003 Closed |
| low | open | Raw-CRLF negative test accepts any nonzero exit |
| low | open | README claims the commands work in either checkout, but legacy CRLF checkouts still fail |
| medium | verified | Attribute test cited by finding fnd_2390 does not exist; line 131 is a fixture assertion |
| medium | verified | D-003 acceptance-test link points to the wrong test |
| medium | verified | Raw-CRLF negative test assumes the CRLF sh block exits nonzero, which is unverified and contradicted by the only observed run |
| medium | verified | Attribute test has no git-absent skip guard |
| medium | verified | Raw-CRLF negative test checks only that the exit code is a number |
| high | verified | eol=lf removes the CRLF case rather than supporting it |
| medium | open | D-007 raw-CRLF negative assertion may fail because sh exits 0 with CRLF input |
| medium | open | Reconciliation doc states an unverified clean-commit result and a .gitattributes claim |
| medium | verified | Raw-CRLF negative test does not check the failure property |
| medium | verified | README and reconciliation doc claim results that were not observed |
| medium | verified | Install-from-CRLF test compares LF with LF and does not run a CRLF README |
| medium | verified | Reconciliation doc attributes autocrlf results to a different commit than the one it reports |
| medium | open | .gitattributes presence is contradicted across sources |
| medium | verified | 'Verified test state' heading overstates results that were not re-run in review |
| medium | verified | Approved scope change is asserted but not evidenced |
| medium | verified | Docs label unobserved results as verified and contradict the .gitattributes file |
| medium | verified | Raw-CRLF negative test does not depend on the fix |
| low | open | Reconciliation doc anchors and headings do not match the test files |
| medium | verified | Doc labels unrun results as observed |
| high | verified | Doc records product-manager scope approval that the reviewed messages do not evidence |
| medium | open | Doc attributes a product-owner decision with no traceable record |
| low | open | Workaround branch of D-007 does not check the cloned commit |
| medium | open | Counts under the heading 'Observed' were never observed in this review |
| low | open | README calls the tr -d '\r' workaround untested, but the D-007 test exercises it |
| low | open | Doc gives two different commits for the same re-run |
| low | open | Recorded results cite a commit other than the reviewed HEAD |
| medium | open | D-007 scope cites an unverifiable product-owner approval |
| low | open | README advice `git add --renormalize .` does not fix CRLF working-tree files |
| low | open | Raw-CRLF test name claims it explains the .gitattributes fix |
| medium | verified | README advice `git add --renormalize .` does not produce LF files in the working tree |
| medium | verified | Reconciliation doc records orchestration state (approval status, commit SHAs, test counts) |
| medium | verified | Doc claims results were observed and cites a stale commit with uncommitted edits |
| low | open | Repository doc records commit SHA and test counts (orchestration state) |
