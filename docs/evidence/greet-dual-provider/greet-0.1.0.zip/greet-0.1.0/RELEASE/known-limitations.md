# Known limitations

## Open non-blocking findings
- [low] Installation test has no explicit CRLF case
- [low] The reconciliation note cites a commit that already contains the installation tests
- [low] The reconciliation misdates the addition of the installation tests
- [low] CRLF section gives a workaround that does not match the README's own install block
- [low] README installation test only checks keywords, not documented behaviour
- [medium] Recorded clean-commit test result has no environment caveat and is unverified
- [low] Exact test counts documented without git-on-PATH caveat
- [low] Raw-CRLF negative test accepts any nonzero exit
- [low] README claims the commands work in either checkout, but legacy CRLF checkouts still fail
- [medium] D-007 raw-CRLF negative assertion may fail because sh exits 0 with CRLF input
- [medium] Reconciliation doc states an unverified clean-commit result and a .gitattributes claim
- [medium] .gitattributes presence is contradicted across sources
- [low] Reconciliation doc anchors and headings do not match the test files
- [medium] Doc attributes a product-owner decision with no traceable record
- [low] Workaround branch of D-007 does not check the cloned commit
- [medium] Counts under the heading 'Observed' were never observed in this review
- [low] README calls the tr -d '\r' workaround untested, but the D-007 test exercises it
- [low] Doc gives two different commits for the same re-run
- [low] Recorded results cite a commit other than the reviewed HEAD
- [medium] D-007 scope cites an unverifiable product-owner approval
- [low] README advice `git add --renormalize .` does not fix CRLF working-tree files
- [low] Raw-CRLF test name claims it explains the .gitattributes fix
- [low] Repository doc records commit SHA and test counts (orchestration state)

## Not implemented / cancelled
- D-008 Documentation does not match implementation: cancelled by cli: Withdrawn: created from a bare docs_accurate=false verdict (rule since removed). Its remaining findings concern docs/defect-reconciliation.md, an orchestration-tracking file that should not exist in the product repository.
