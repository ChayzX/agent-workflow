# Original goal (immutable baseline, sha256 90e482bb28795c5d53df997b1af478c2eed47394893056e75d6eda3acdf8a711)

# greet — dual-provider live acceptance

A tiny dependency-free Node.js (>= 22) ESM package with two functions, each with node:test tests, and a README.
