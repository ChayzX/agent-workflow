# greet 0.1.0

Built from `723584c6f64af04e4e37608fd2df6752901b5674`.

## Changes
- D-001 Requirement R-001 not satisfied: hello(name) greeting
- D-002 Requirement R-002 not satisfied: shout(text) uppercase
- D-003 Requirement R-003 not satisfied: README
- D-005 Installation is not reproducible
- D-009 Installation is not reproducible
- W-001 Implement hello(name)
- W-002 Implement shout(text)
- D-004 Documentation does not match implementation
- D-006 Recorded defects D-001..D-003 conflict with the implemented code
- D-007 The documented installation fails with CRLF line endings
- W-003 Write README
