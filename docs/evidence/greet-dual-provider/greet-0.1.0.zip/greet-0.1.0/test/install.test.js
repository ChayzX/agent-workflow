import assert from "node:assert/strict";
import { execFile, spawnSync } from "node:child_process";
import { mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { delimiter, join } from "node:path";
import { fileURLToPath } from "node:url";
import { test } from "node:test";
import { promisify } from "node:util";

const run = promisify(execFile);
const root = fileURLToPath(new URL("../", import.meta.url));
const gitEnv = {
  ...Object.fromEntries(Object.entries(process.env).filter(([key]) => !key.startsWith("GIT_"))),
  GIT_CONFIG_GLOBAL: "/dev/null",
  GIT_CONFIG_NOSYSTEM: "1",
};
const nestedInstall = {
  skip:
    process.env.GREET_INSTALL_TEST === "1"
      ? "nested run inside the installation test"
      : !hasUsableGitRepository() && "no usable git repository (e.g. a stale linked-worktree .git file); the commit under test cannot be cloned",
};

function hasUsableGitRepository() {
  const result = spawnSync("git", ["rev-parse", "--verify", "HEAD^{commit}"], { cwd: root, env: gitEnv });
  return result.status === 0;
}

// Extracts the Installation sh block from raw README text, accepting LF or CRLF terminators.
// The returned commands have LF-only line breaks, so no carriage return reaches the shell.
function installationCommands(readme) {
  const section = readme.split(/(?=^## )/m).find((section) => /^## Installation\r?\n/.test(section));
  assert.ok(section, "README has an Installation section");
  const block = section.match(/^```sh\r?\n([\s\S]*?)^```\r?$/m);
  assert.ok(block, "Installation section has a sh block");
  const commands = block[1].replace(/\r\n/g, "\n");
  assert.doesNotMatch(commands, /\r/, "extracted commands contain no carriage return");
  assert.match(commands, /^[ \t]*npm[ \t]+test[ \t]*\r?$/m, "Installation block includes an npm test command");
  return commands;
}

async function withTemporaryDirectory(verify) {
  const directory = mkdtempSync(join(tmpdir(), "greet-install-"));
  try {
    await verify(directory);
  } finally {
    rmSync(directory, { recursive: true, force: true });
  }
}

async function git(args, options) {
  try {
    return await run("git", args, { env: gitEnv, ...options });
  } catch (error) {
    throw new Error(`git ${args.join(" ")} failed (code ${error.code})\nstderr:\n${error.stderr}`, { cause: error });
  }
}

async function createFixture(parent) {
  const { stdout } = await git(["rev-parse", "HEAD"], { cwd: root });
  const commit = stdout.trim();
  const source = join(parent, "source repo");
  // Use Git's transfer protocol so it records the shallow boundary.
  await git(["clone", "--bare", "--no-local", "--depth", "1", root, source], { cwd: parent });
  const readme = await git(["show", `${commit}:README.md`], { cwd: root });
  const installParent = join(parent, "installation");
  mkdirSync(installParent);
  return { source, commit, readme: readme.stdout, installParent };
}

function runInstallation(commands, cwd, source, overrides = {}) {
  return run("sh", ["+e", "-c", commands], {
    cwd,
    env: {
      ...gitEnv,
      ...overrides,
      GREET_REPO_URL: source,
      GREET_INSTALL_TEST: "1",
      npm_config_offline: "true",
      npm_config_cache: join(cwd, "npm-cache"),
      npm_config_globalconfig: join(cwd, "global.npmrc"),
      npm_config_userconfig: join(cwd, "user.npmrc"),
    },
  });
}

test("D-005: documented installation succeeds from a clean clone of the committed HEAD", nestedInstall, async () => {
  await withTemporaryDirectory(async (parent) => {
    const { source, commit, readme, installParent } = await createFixture(parent);
    const commands = installationCommands(readme);
    try {
      await runInstallation(commands, installParent, source);
    } catch (error) {
      throw new Error(`README installation failed\n${error.message}\nstdout:\n${error.stdout}\nstderr:\n${error.stderr}`, { cause: error });
    }
    const checkout = join(installParent, "greet");
    const clone = await git(["rev-parse", "HEAD"], { cwd: checkout });
    assert.equal(clone.stdout.trim(), commit);
    await git(["fsck", "--no-dangling"], { cwd: checkout });
  });
});

test("D-007: .gitattributes keeps the working tree LF under core.autocrlf=true, so the documented installation succeeds", nestedInstall, async () => {
  await withTemporaryDirectory(async (parent) => {
    const { source, commit, readme, installParent } = await createFixture(parent);
    const commands = installationCommands(readme);
    // Force the clone to convert LF to CRLF the way a Windows checkout with autocrlf would.
    const crlfCheckout = {
      GIT_CONFIG_COUNT: "1",
      GIT_CONFIG_KEY_0: "core.autocrlf",
      GIT_CONFIG_VALUE_0: "true",
    };
    try {
      await runInstallation(commands, installParent, source, crlfCheckout);
    } catch (error) {
      throw new Error(`README installation failed from a CRLF checkout\n${error.message}\nstdout:\n${error.stdout}\nstderr:\n${error.stderr}`, { cause: error });
    }
    const checkout = join(installParent, "greet");
    const clone = await git(["rev-parse", "HEAD"], { cwd: checkout });
    assert.equal(clone.stdout.trim(), commit);

    const eol = await git(["ls-files", "--eol", "README.md", "package.json", "src", "test"], { cwd: checkout });
    for (const line of eol.stdout.trim().split("\n")) {
      assert.match(line, /w\/lf\b/, `working tree must use LF: ${line}`);
      assert.doesNotMatch(line, /w\/crlf/, `working tree must not use CRLF: ${line}`);
    }
    // The README in the checkout must also run its documented installation without normalization.
    const checkoutReadme = readFileSync(join(checkout, "README.md"), "utf8");
    assert.doesNotMatch(checkoutReadme, /\r/, "checked-out README has no carriage returns");
    assert.equal(installationCommands(checkoutReadme), commands);
  });
});

test("D-005: documented installation stops before npm when the destination is occupied", nestedInstall, async () => {
  await withTemporaryDirectory(async (parent) => {
    const { source, readme, installParent } = await createFixture(parent);
    const destination = join(installParent, "greet");
    mkdirSync(destination);
    writeFileSync(join(destination, "existing-file"), "occupied\n");

    const bin = join(parent, "bin");
    mkdirSync(bin);
    writeFileSync(join(bin, "npm"), "#!/bin/sh\nprintf '%s\\n' 'npm was invoked'\n", { mode: 0o755 });

    const result = runInstallation(installationCommands(readme), installParent, source, {
      LC_ALL: "C",
      PATH: `${bin}${delimiter}${process.env.PATH}`,
    });
    await assert.rejects(result, (error) => {
      assert.equal(typeof error.code, "number", error.message);
      assert.match(error.stderr, /destination path 'greet' already exists and is not an empty directory/);
      assert.doesNotMatch(error.stdout, /npm was invoked/);
      return true;
    });
  });
});

test("D-007 (documentation test, sh behaviour only): the sh block with raw CRLF bytes fails in sh; not evidence that the fix works",nestedInstall, async () => {
  await withTemporaryDirectory(async (parent) => {
    const { source, readme, installParent } = await createFixture(parent);
    const crlfReadme = readme.replace(/\r?\n/g, "\r\n");
    const block = crlfReadme.match(/^## Installation\r\n[\s\S]*?^```sh\r\n([\s\S]*?)^```\r\n/m);
    assert.ok(block, "CRLF README has an Installation sh block");
    assert.match(block[1], /\r\n/, "block keeps raw CRLF terminators");
    const script = join(parent, "install-crlf.sh");
    writeFileSync(script, block[1]);
    const result = run("sh", ["-e", script], {
      cwd: installParent,
      env: { ...gitEnv, GREET_REPO_URL: source, GREET_INSTALL_TEST: "1", LC_ALL: "C" },
    });
    // Unnormalized CRLF commands cannot succeed: the CR becomes part of the directory name and
    // the following cd or npm invocation fails. Assert a nonzero exit and a shell error on stderr.
    await assert.rejects(result, (error) => {
      assert.ok(Number.isInteger(error.code) && error.code !== 0, `expected nonzero exit, got ${error.code}`);
      assert.match(error.stderr, /can't cd|not found|Unknown command/, `expected a shell failure on stderr:\n${error.stderr}`);
      return true;
    });
  });
});

test("D-009: installation commands are extracted from a CRLF README without carriage returns", () => {
  const readme = installationReadme().replace(/\n/g, "\r\n");
  const commands = installationCommands(readme);
  assert.ok(!commands.includes("\r"), "commands contain no carriage return");
});

const attributeSkip = !hasUsableGitRepository() && "no usable git repository or git unavailable; cannot query attributes";

test("D-009: .gitattributes forces LF line endings so CRLF checkouts keep the documented commands valid", { skip: attributeSkip }, () => {
  const result = spawnSync("git", ["check-attr", "eol", "text", "--", "README.md", "package.json", "src/hello.js"], { cwd: root, env: gitEnv, encoding: "utf8" });
  assert.equal(result.status, 0, result.stderr);
  const lines = result.stdout.trim().split("\n");
  assert.equal(lines.length, 6);
  for (const line of lines) {
    if (line.includes(": eol:")) assert.match(line, /: lf$/, line);
    else assert.doesNotMatch(line, /: (unset|unspecified)$/, line);
  }
});

function installationReadme() {
  return readFileSync(join(root, "README.md"), "utf8").replace(/\r\n/g, "\n");
}
