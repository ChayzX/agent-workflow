import { test } from 'node:test';
import assert from 'node:assert/strict';
import { shout } from '../src/shout.js';

test('R-002: shout("hi") returns "HI"', () => {
  assert.equal(shout('hi'), 'HI');
});

test('R-002: shout preserves existing punctuation', () => {
  assert.equal(shout('hi!'), 'HI!');
});

test('R-002: shout rejects non-string input', () => {
  assert.throws(() => shout(42), TypeError);
  assert.throws(() => shout(undefined), TypeError);
});
