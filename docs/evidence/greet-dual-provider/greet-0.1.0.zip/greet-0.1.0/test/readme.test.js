import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { test } from "node:test";

test("README setup requires no dependency installation", () => {
  const packageJson = JSON.parse(readFileSync(new URL("../package.json", import.meta.url), "utf8"));
  for (const field of ["dependencies", "devDependencies", "optionalDependencies", "peerDependencies"]) {
    assert.deepEqual(packageJson[field] ?? {}, {}, `${field} must be empty for the documented setup`);
  }
});

const repositoryRoot = new URL("../", import.meta.url);
const readme = readFileSync(new URL("README.md", repositoryRoot), "utf8");

// Parses the Usage section of the raw README text without normalizing line endings.
// Line terminators may be LF or CRLF; the captured code keeps its original terminators.
// Returns [{ name, source }] for each example.
function extractUsageExamples(text) {
  const usageSections = text.split(/(?=^## )/m).filter((section) => /^## Usage\r?\n/.test(section));
  assert.equal(usageSections.length, 1);

  const examples = [...usageSections[0].matchAll(/^\*\*`(\w+)\(\w+\)`\*\*\r?\n[\s\S]*?^```js\r?\n([\s\S]*?)^```\r?$/gm)];
  assert.deepEqual(examples.map(([, name]) => name), ["hello", "shout"]);

  return examples.map(([, name, source]) => {
    assert.match(source, new RegExp(`^assert\\.equal\\(${name}\\(`, "m"));
    return { name, source };
  });
}

async function runUsageExamples(examples) {
  for (const { name, source } of examples) {
    // A data URL module needs absolute URLs for repository-relative imports.
    const moduleSource = source.replace(/from "(\.\/[^"]+)"/g, (_, path) =>
      `from "${new URL(path, repositoryRoot).href}"`,
    );
    // Give each invocation its own module URL so both newline variants execute the examples.
    const moduleUrl = `data:text/javascript,${encodeURIComponent(moduleSource)}#${name}`;
    await import(moduleUrl);
  }
}

test("R-003: README Usage examples for hello and shout produce the documented output with LF", async () => {
  const examples = extractUsageExamples(readme.replace(/\r\n/g, "\n"));
  await runUsageExamples(examples);
});

test("D-007: README Usage examples for hello and shout produce the documented output with CRLF", async () => {
  const crlfReadme = readme.replace(/\r?\n/g, "\r\n");
  assert.match(crlfReadme, /\r\n/);
  const crlfExamples = extractUsageExamples(crlfReadme);
  assert.ok(crlfExamples.every(({ source }) => source.includes("\r\n")), "CRLF input keeps CRLF terminators");

  // The CRLF examples must be the LF examples, differing only by the carriage returns.
  const lfExamples = extractUsageExamples(readme.replace(/\r\n/g, "\n"));
  assert.deepEqual(
    crlfExamples.map(({ name, source }) => ({ name, source: source.replace(/\r\n/g, "\n") })),
    lfExamples,
  );

  await runUsageExamples(crlfExamples);
});
