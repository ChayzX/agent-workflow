import { test } from "node:test";
import assert from "node:assert/strict";
import { hello } from "../src/hello.js";

test("R-001: hello('Ada') returns exactly 'Hello, Ada!'", () => {
  assert.equal(hello("Ada"), "Hello, Ada!");
});

test("R-001: hello trims surrounding whitespace from the name", () => {
  assert.equal(hello("  Ada  "), "Hello, Ada!");
});

test("R-001: hello throws TypeError for non-string input", () => {
  assert.throws(() => hello(42), TypeError);
  assert.throws(() => hello(undefined), TypeError);
});

test("R-001: hello throws RangeError for empty or whitespace-only name", () => {
  assert.throws(() => hello(""), RangeError);
  assert.throws(() => hello("   "), RangeError);
});
