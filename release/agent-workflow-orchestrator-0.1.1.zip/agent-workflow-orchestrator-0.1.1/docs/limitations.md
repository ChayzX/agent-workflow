# Known limitations (v0.1.0)

Stated plainly so nothing is over-claimed. See `docs/acceptance-matrix.md` for what is verified, simulated or unverified.

## Integration
- **GitHub mode was not exercised against the live GitHub API in the build environment.** The session's GitHub access
  was a repository-scoped proxy token, which the REST API rejects (HTTP 401), so the orchestrator could not use it.
  The REST/GraphQL client and sync are contract-tested against an in-memory fake covering issues, sub-issues,
  dependencies, Projects v2 fields, PRs, checks, merges and releases. The live acceptance steps are in
  `docs/live-acceptance.md`.
- **Fine-grained PATs cannot manage user-owned Projects (v2)** (a GitHub limitation). Use a classic PAT with `repo`,
  `project` and `workflow` scopes for personal repositories. Without `workflow`, GitHub refuses any push that touches
  `.github/workflows/`; the orchestrator then blocks that item with the exact fix instead of retrying.
- **Issues first synced by 0.1.0 have no recorded state.** On the first reconcile after upgrading, an open issue of a
  finished item is treated as sync lag and re-closed once (a human reopen made before the upgrade is not detected);
  from then on, state is recorded and human changes are tracked exactly.
- **A GitHub issue has at most one sub-issue parent** (a GitHub rule). A work item that covers several requirements
  appears as a sub-issue of the first requirement only; its other requirements reference it in the issue body.
- **The live GitHub run (operator verification, 2026-11-28)** exercised issues, sub-issues, dependencies, Projects
  fields, PRs, the human-review approval path, an exact-SHA merge and crash-replay idempotency, and found the defects
  fixed in the follow-up (credentials for git pushes, reconciliation after merges, push retry storms). A red-CI PR was
  not observed, and a GitHub Release was not published; see `docs/evidence/operator-verification/REPORT.md`.
- **Cloud execution (Codex Cloud, Claude Code cloud) is assessed but not implemented as an adapter.** See
  `docs/cloud-assessment.md`.
- **Oracle Cloud deployment is prepared** (manifests, IAM examples, preflight) **but was never run** against a real
  tenancy.
- **Claude exposes no usage-free capacity probe.** After a reset, one canary task confirms capacity. Codex is probed
  through `codex app-server` at no usage cost.
- **Usage-limit message formats change over time.** Structured provider signals are preferred; text parsing is the
  fallback, with fixtures from real output. Unknown formats fall back to bounded backoff (15 min to 6 h), never to a
  tight retry loop.

## Execution model
- **One supervisor per data directory, single node.** There is no high-availability failover between hosts; recovery
  works by restarting on the same host or restoring a backup.
- **Path-hint conflict avoidance depends on plan quality.** Real merge conflicts are still handled through remediation.
- **Debates and audits use bounded rounds**, so a determined disagreement ends with the decision owner's ruling,
  recorded with its rationale. Unresolved security-critical objections block the decision instead.
- **Completion audits may be conservative.** A requirement either auditor marks unsatisfied becomes work. After 6 failed
  audit rounds the project is blocked for operator review instead of looping.
- **Requirement verification is limited to auditors plus deterministic gates.** Gates prove only what the project's tests
  prove, and auditors cannot verify behavior that has no observable evidence.
- **Clean-environment verification** of a release runs the declared `verify_commands` in a fresh directory inside
  bubblewrap. It is not a fresh VM or container image; the build host had no container daemon.

## Security
- **Confinement requires bubblewrap.** Without a working bubblewrap the supervisor refuses to run agents and gates
  (fail closed). Setting `security.sandbox` / `security.agentSandbox` to `"none"` runs them unconfined with only a
  scrubbed environment; each opt-out is written to the audit log at every supervisor start. See `docs/security.md`.
- **The dashboard has a single operator token** and no RBAC. Keep it on loopback or behind TLS.
- **HawkScan DAST was not run in the build environment** (installing the CLI was not permitted there). A manual probe of
  authentication, CSRF, headers, input limits, traversal and throttling was run, and two issues it found were fixed.

- **Operator `cancel` does not close an open pull request** (GitHub mode). Integration states (`merge_ready`, `merging`,
  `merged`) refuse cancellation, but an item blocked while its PR was open can be cancelled. Its PR then stays open on
  GitHub until someone closes it.
- **The `unblock` and `cancel` commands are CLI-only.** The dashboard does not offer them.

## Product
- The dashboard is functional and accessible-minded (semantic HTML, keyboard tabs, focus styles, `aria-live`, contrast
  tokens). It has not had a formal WCAG audit.
- Metrics are only what providers report. Claude reports cost estimates; Codex reports tokens. No balances or costs are
  estimated by the orchestrator.
